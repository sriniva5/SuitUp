package com.example.akila.myapplication;

// Name: Ananya Srinivasan
// Course: CSC 415
// Semester: Fall 2017
// Instructor: Dr. Pulimood
// SuitUp
// Description: An android app for work clothing donations
// Filename: Donation
// Description: The donation class manages the methods related to donations
// Last modified on: 10 November 2017

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Donation extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation);
    }

    /*
    public setDonation(String item, String gender, String color, int size, String system){}
     */
}
